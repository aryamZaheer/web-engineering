#https://platform.openai.com/api-keys
#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
from flask import Flask, request, jsonify
from flask_cors import CORS
import openai

app = Flask(__name__)  # ✅ Correct initialization
CORS(app) 
openai.api_key = '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'
@app.route('/', methods=['GET'])
def home():
    return "AI Chatbot Backend Running"

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message', '')

    if not user_message:
        return jsonify({'reply': "Please enter a message."})

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": user_message}
            ]
        )
        bot_reply = response['choices'][0]['message']['content'].strip()
        return jsonify({'reply': bot_reply})
    except Exception as e:
        return jsonify({'reply': f"Error: {str(e)}"})

if __name__ == '__main__':
    app.run(debug=True)
